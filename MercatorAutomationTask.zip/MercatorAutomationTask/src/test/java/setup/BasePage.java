package setup;

import org.openqa.selenium.WebDriver;

public class BasePage {
	public static WebDriver driver;
}
