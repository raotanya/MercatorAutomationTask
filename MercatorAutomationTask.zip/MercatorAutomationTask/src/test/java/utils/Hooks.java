package utils;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import setup.BasePage;
import setup.SetBrowser;

public class Hooks extends BasePage{

    SetBrowser browsersetup = new SetBrowser();
    private static final int WAIT_SEC = 60;

    public void launchBrowser() {
        browsersetup.selectBrowser();
        driver.manage().timeouts().implicitlyWait(WAIT_SEC, TimeUnit.SECONDS);
        driver.manage().window().maximize();
    }
    
    @AfterTest
    public void tearDown() {
    	driver.quit();
    }
}

