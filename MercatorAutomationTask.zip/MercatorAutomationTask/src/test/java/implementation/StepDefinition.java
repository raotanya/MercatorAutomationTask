package implementation;

import org.testng.Assert;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import pages.FindHighPriceItemAndAddToCart;
import pages.HomePage;
import setup.BasePage;
import setup.LoadTestProperties;
import utils.Hooks;

public class StepDefinition extends Hooks{
	
	@Given("^I am navigating to the shopping website and stand in the home page$")
    public void i_access_dresses_website_and_navigate_to_home_page() {
		launchBrowser();
		driver.get(LoadTestProperties.getproperty("url"));
    }
	
	@When("^I click the dress option$")
	public void i_click_dress_option() {
		HomePage o = new HomePage();
		Assert.assertTrue(o.clickDressText(),"Dresses link not clicked for some resons.....");
	}
	
	@And("^I filter the highest price item and adding into the cart$")
	public void i_filter_highest_price_and_add_to_the_cart() {
		FindHighPriceItemAndAddToCart obj = new FindHighPriceItemAndAddToCart();
		Assert.assertTrue(obj.addhighpricePriceItemToCart(),"Some reasons items not added properly");
	}
}

