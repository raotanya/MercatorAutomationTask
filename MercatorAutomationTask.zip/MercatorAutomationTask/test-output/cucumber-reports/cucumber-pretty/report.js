$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("resources/features/AddHighestPriceItemIntoCart.feature");
formatter.feature({
  "line": 1,
  "name": "Select the dresses which has highest price and add the same into cart",
  "description": "",
  "id": "select-the-dresses-which-has-highest-price-and-add-the-same-into-cart",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Select_the_dresses_which_has_highest_price_and_add_the_same_into_cart",
  "description": "",
  "id": "select-the-dresses-which-has-highest-price-and-add-the-same-into-cart;select-the-dresses-which-has-highest-price-and-add-the-same-into-cart",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "I am navigating to the shopping website and stand in the home page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "I click the dress option",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "I filter the highest price item and adding into the cart",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.i_access_dresses_website_and_navigate_to_home_page()"
});
formatter.result({
  "duration": 9926828400,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.i_click_dress_option()"
});
formatter.result({
  "duration": 2344312200,
  "error_message": "java.lang.AssertionError: Dresses link not clicked for some resons..... did not expect to find [true] but found [false]\r\n\tat org.testng.Assert.fail(Assert.java:97)\r\n\tat org.testng.Assert.failNotEquals(Assert.java:969)\r\n\tat org.testng.Assert.assertTrue(Assert.java:43)\r\n\tat implementation.StepDefinition.i_click_dress_option(StepDefinition.java:24)\r\n\tat ✽.When I click the dress option(resources/features/AddHighestPriceItemIntoCart.feature:5)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "StepDefinition.i_filter_highest_price_and_add_to_the_cart()"
});
formatter.result({
  "status": "skipped"
});
});